Novel biomarkers identification by multiomics data integration (KTH, 2023)

Project Supervisor:	Dr. Lingqi Meng (Scilifelab)
Project authored by:	Jonas Eriksson, Melissa Kahilainen, Erika Sandell, Ellinor Wijk and Gabriel Sjöblom
Code authored by: 	Erika Sandell, Gabriel Sjöblom

Distributed under GNU General Public License version 3
